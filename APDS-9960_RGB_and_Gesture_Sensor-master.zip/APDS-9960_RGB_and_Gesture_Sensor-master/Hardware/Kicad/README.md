# What Are these Files?

These are Kicad hardware files, gerber files, and renders of the design. Created by [WyoLum](https://wyolum.com/).

# License

This product is open source! These Eagle files are released under the Creative Commons Share-Alike Attribution license ([CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/us/)).

Please use, reuse, and modify these files as you see fit. Please maintain attribution and release anything derivative under the same license.

- Your friends at SparkFun.